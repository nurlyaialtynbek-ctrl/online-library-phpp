# Дерекқор құрылымы және ER-диаграмма (8-апта)

```mermaid
erDiagram
    USERS ||--o{ BOOKS : "adds (user_id)"
    CATEGORIES ||--o{ BOOKS : "contains (category_id)"
    USERS ||--o{ REVIEWS : "writes (user_id)"
    BOOKS ||--o{ REVIEWS : "has (book_id)"

    USERS {
        int id PK
        varchar full_name
        varchar email UK
        varchar password_hash
        enum role "user | admin"
        timestamp created_at
    }

    CATEGORIES {
        int id PK
        varchar name UK
        varchar description
    }

    BOOKS {
        int id PK
        varchar title
        varchar author
        int publish_year
        text description
        varchar cover_image
        int available_copies
        int category_id FK
        int created_by FK
        timestamp created_at
    }

    REVIEWS {
        int id PK
        int book_id FK
        int user_id FK
        int rating
        text comment
        timestamp created_at
    }
```
