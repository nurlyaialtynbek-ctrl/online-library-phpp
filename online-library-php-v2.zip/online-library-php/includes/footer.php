</main>
<footer class="footer">
    <div class="container">
        <p>&copy; <?= date('Y') ?> Онлайн кітапхана жүйесі. PHP & MySQL жеке жобалық жұмыс.</p>
    </div>
</footer>
<script src="assets/js/main.js"></script>
</body>
</html>
