<?php require_once __DIR__ . '/auth_check.php'; ?>
<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Онлайн Кітапхана</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="navbar">
    <div class="container nav-content">
        <a href="index.php" class="logo">📚 Онлайн Кітапхана</a>
        <nav class="nav-links">
            <a href="index.php">Каталог</a>
            <?php if (isLoggedIn()): ?>
                <a href="book_form.php">+ Кітап қосу</a>
                <a href="profile.php">Профиль (<?= e($_SESSION['user_name']) ?>)</a>
                <a href="logout.php" class="btn-outline">Шығу</a>
            <?php else: ?>
                <a href="login.php">Кіру</a>
                <a href="register.php" class="btn-primary">Тіркелу</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<main class="container main-content">
