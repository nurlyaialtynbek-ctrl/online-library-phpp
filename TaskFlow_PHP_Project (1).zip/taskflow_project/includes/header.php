<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TaskFlow — Тапсырмалар менеджері</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<nav class="navbar">
    <a href="index.php" class="logo">TaskFlow</a>
    <div class="nav-links">
        <?php if (isset($_SESSION['user_id'])): ?>
            <span>Сәлем, <b><?= htmlspecialchars($_SESSION['username']) ?></b>!</span>
            <a href="profile.php">Профиль</a>
            <a href="task_form.php" class="btn">+ Жаңа тапсырма</a>
            <a href="logout.php" class="btn btn-danger">Шығу</a>
        <?php else: ?>
            <a href="login.php">Кіру</a>
            <a href="register.php" class="btn">Тіркелу</a>
        <?php endif; ?>
    </div>
</nav>
<main class="container">
